class Item < ApplicationRecord
  belongs_to :list
end
